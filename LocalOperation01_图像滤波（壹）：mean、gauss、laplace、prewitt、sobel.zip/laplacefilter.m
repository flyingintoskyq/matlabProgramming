function imgLaplace = laplacefilter(img,alpha)
% img: image
% filterSize: if=5, it means 5*5
% alpha: Shape of the Laplacian, specified as a scalar in the range [0 1].

% Generate laplace filter
img = double(img);
laplaceFilter = fspecial('laplacian', alpha);
% cov
imgLaplace = convolutionM(img, laplaceFilter);
imgLaplace = uint8(imgLaplace);

end

