function imgSobel = sobelfilter(img)
% img: image

% Generate sobel filter
img = double(img);
sobelFilter = fspecial('sobel');
% cov
imgSobel = convolutionM(img, sobelFilter);
imgSobel = uint8(imgSobel);

end

