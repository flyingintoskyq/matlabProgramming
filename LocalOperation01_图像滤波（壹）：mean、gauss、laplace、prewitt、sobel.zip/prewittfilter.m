function imgPrewitt = prewittfilter(img)
% img: image

% Generate prewitt filter
img = double(img);
prewittFilter = fspecial('prewitt');
% cov
imgPrewitt = convolutionM(img, prewittFilter);
imgPrewitt = uint8(imgPrewitt);

end

