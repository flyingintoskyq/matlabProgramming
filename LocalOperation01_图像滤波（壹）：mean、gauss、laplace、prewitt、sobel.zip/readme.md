# 1 Document

main.m为主文件

meanfilter.m为均值滤波函数文件

gaussianfilter.m为均值高斯滤波函数文件

laplacefilter.m为拉普拉斯滤波函数文件

prewittfilter.m为prewitt滤波函数文件

sobelfilter.m为sobel滤波函数文件

convolutionM.m为滤波卷积滤波函数文件

所选图像为matlab自带图库图像，也可以手动添加



# 2 Run

直接运行main.m即可