% imgOrg = rgb2gray(imread("peppers.png"));
imgOrg = imread("peppers.png");
subplot(2,3,1);
imshow(imgOrg);
title("Originall img");

% mean filter
imgMean = meanfilter(imgOrg, 3); % Generally, the size of a filter is an odd num
subplot(2,3,2);
imshow(imgMean);
title("Mean filter img");

% gaussian filter
imgGaussian = gaussianfilter(imgOrg, 3, 1);
subplot(2,3,3);
imshow(imgGaussian);
title("Gaussian filter img");

% laplace filter
imgSobel = laplacefilter(imgOrg, 0.2);
subplot(2,3,4);
imshow(imgSobel);
title("Laplace filter img");

% prewitt filter
imgSobel = prewittfilter(imgOrg);
subplot(2,3,5);
imshow(imgSobel);
title("Prewitt filter img");

% sobel filter
imgSobel = sobelfilter(imgOrg);
subplot(2,3,6);
imshow(imgSobel);
title("Sobel filter img");
