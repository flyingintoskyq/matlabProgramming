function imgGaussian = gaussianfilter(img,filterSize,sigma)
% img: image
% filterSize: if=5, it means 5*5
% sigma: Standard deviation, specified as a positive number.

% Generate gaussian filter
img = double(img);
gaussianFilter = fspecial('gaussian', filterSize, sigma);
% cov
imgGaussian = convolutionM(img, gaussianFilter);
imgGaussian = uint8(imgGaussian);

end

