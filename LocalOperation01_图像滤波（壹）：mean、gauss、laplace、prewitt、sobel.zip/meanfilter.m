function imgMean = meanfilter(img,filterSize)
% img: image
% filterSize: if=5, it means 5*5

% Generate mean filter
img = double(img);
meanFilter = fspecial('average', filterSize);
% cov
imgMean = convolutionM(img, meanFilter);
imgMean = uint8(imgMean);

end

